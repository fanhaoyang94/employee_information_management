export type ActivityModel = {
  name: string;
  price: number;
  unit: string;
  category: string;
  color: string;
  sort: string;
  sortUnit: string;
};
