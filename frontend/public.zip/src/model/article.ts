export interface ArticleModel {
  id: number;
  title: string;
  content: string;
  type: string;
}
