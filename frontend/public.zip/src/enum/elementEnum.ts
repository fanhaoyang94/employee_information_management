export enum ElementEnum {
  ELEMENT_MESSAGE_BOX_SIZE = "300px",
  ELEMENT_MESSAGE_BOX_CLASS = "message-box-custom-class"
}
