export enum SecretEnum {
  GITHUB_ACCESS_TOKEN = "xxx"
}
