export enum UserEnum {
  GITHUB_REPOSITORY = "https://github.com/cloudhao1999/cloud-app-admin",
  TOKEN_KEY = "cloud-auth-token",
  GITHUB_USER = "cloudhao1999",
  GITHUB_REPO = "cloud-app-admin"
}
