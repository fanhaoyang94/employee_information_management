export enum CacheEnum {
  HISTORY_MENU = "history_menu",
  MENU_CLOSE_STATE = "menu_close_state",
  REDIRECT_NAME = "redirect_name"
}
