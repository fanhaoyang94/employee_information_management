export enum TagColorEnum {
  FEAT = "#0bbd87",
  FIX = "#f5c518",
  DOCS = "#4b5261",
  STYLE = "#ec407a",
  CHORE = "#d81b60",
  UNKNOWN = "#666666"
}
