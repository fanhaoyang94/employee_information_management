export enum EchartEnum {
  ECHART_MIN_WIDTH = 250
}
