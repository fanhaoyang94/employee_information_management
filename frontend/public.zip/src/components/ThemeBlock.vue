<script setup lang="ts">
// 用于解决主题样式无法导入的问题
</script>

<template>
  <div class="light dark sky"></div>
</template>

<style scoped></style>
