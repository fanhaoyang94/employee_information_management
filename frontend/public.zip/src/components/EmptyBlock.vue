<script setup lang="ts"></script>

<template>
  <div class="h-full w-full">
    <slot></slot>
  </div>
</template>

<style scoped></style>
