import "./tailwindcss.css";
export function setupTailwindcss() {}
