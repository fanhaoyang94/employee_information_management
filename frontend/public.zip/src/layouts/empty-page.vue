<script lang="ts" setup>
import PageView from "./pages/index.vue";
</script>
<template>
  <el-container class="h-full w-full font-sans">
    <PageView />
  </el-container>
</template>

<style scoped></style>
