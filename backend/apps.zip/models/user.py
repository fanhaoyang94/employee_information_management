from dbdriver.SQLHelper import db


class User(object):

    def create_table(self):
        sql = '''
            CREATE TABLE IF NOT EXISTS users (
                id INT PRIMARY KEY AUTO_INCREMENT,
                name VARCHAR(80) UNIQUE NOT NULL,
                email VARCHAR(120) UNIQUE NOT NULL,
                phone CHAR(11) UNIQUE NOT NULL,
                gender CHAR(1) NOT NULL,
                password VARCHAR(255) NOT NULL,
                birthday DATE NOT NULL,
                education VARCHAR(50) NOT NULL,
                major VARCHAR(100) NOT NULL,
                address VARCHAR(255) NOT NULL,
                department VARCHAR(255) NOT NULL,
                employment_status VARCHAR(20) DEFAULT '试用'
            )
            '''
        with db as cursor:
            cursor.execute(sql)
