import inspect

from dbdriver.SQLHelper import db
import importlib


class ModuleManage(object):
    def __init__(self):
        self.drop_all()

    def drop_all(self):
        sql = """SELECT CONCAT('DROP TABLE ', table_name, ';') AS query
        FROM information_schema.tables WHERE table_schema = 'eimDB';"""
        with db as cursor:
            cursor.execute(sql)

    def create_all(self):
        module_manage = importlib.import_module("models")
        modules = inspect.getmembers(module_manage, inspect.isclass)
        for class_name, class_obj in modules:
            if hasattr(class_obj, 'create_table'):
                instance = class_obj()
                getattr(instance, 'create')()
