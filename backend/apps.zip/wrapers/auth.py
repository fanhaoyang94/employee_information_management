import functools
from flask import session, jsonify


def with_auth(func):
    """装饰器：验证session

    使用方法：
    ```
    @with_auth()
    def function():
        pass
    ```
    """

    @functools.wraps(func)
    def auth_check(*args, **kwargs):
        # TODO: 验证角色权限
        username = session.get('username')
        if not username:
            result = {
                "code": -1,
                "msg": "未登录"
            }
            return jsonify(result)
        return func(*args, **kwargs)
    return auth_check
