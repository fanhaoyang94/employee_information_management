
#   【JWt配置】
JWT_SECRET_KEY = 'your_jwt_secret_key'
JWT_TOKEN_LOCATION = ['headers']
JWT_BLACKLIST_ENABLED = True
JWT_BLACKLIST_TOKEN_CHECKS = ['access', 'refresh']

#   【数据库配置】
DB_HOST = '127.0.0.1'
DB_PORT = '3363'
DB_USER = 'rooot'
DB_PWD = 'root123'
