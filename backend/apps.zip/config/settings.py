# -*- coding: UTF-8 -*-
"""
    默认配置文件，可以通过 localsettings.py 进行覆盖设置
    localsettings.py
    1.文件不上传 Git 多人协作模式可以通过此文件配置本地数据库等本地化配置
    2.可以在服务器上写一份默认localsettings文件配置的正式服务数据库配置或者敏感配置信息，可达到保护生产数据用户名密码等敏感信息的作用
"""
from datetime import timedelta

SECRET_KEY = 'the-blue-lotus'

#   【JWt配置】
JWT_SECRET_KEY = 'employee_information_management'
JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=1)  # 设置普通JWT过期时间
JWT_TOKEN_LOCATION = ['headers']  # 用于指定从请求中获取 JWT 令牌的位置
JWT_BLACKLIST_ENABLED = True  # 用于启用或禁用令牌黑名单功能
JWT_BLACKLIST_TOKEN_CHECKS = ['access', 'refresh']  # 用于指定哪些类型的令牌将被加入到令牌黑名单中

#   【数据库配置】
DB_NAME = "eimDB"
DB_HOST = '127.0.0.1'
DB_PORT = '3363'
DB_USER = 'rooot'
DB_PWD = 'root123'

try:
    from localsettings import *

except ImportError:
    pass
