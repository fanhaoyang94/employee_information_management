from flask import Flask
from utils.auth import jwt
# from wrapers.auth import with_auth


def create_app():
    app = Flask(__name__)
    # app.secret_key = "fdfghjkl"

    app.config.from_object('config.settings')

    jwt.init_app(app)
    """
    @app.before_request
    @with_auth
    def before():
        # 所有的路由进入时会先执行此处代码
        pass

    @app.after_request
    def after():
        # 所有的路由结束时会执行此处代码
        pass  
    """

    """
    @app.route('/index')
    def index():
        return 'index'
    """

    from .views.login import auth_view
    # app.register_blueprint(login, url_prefix='/auth')
    app.register_blueprint(auth_view)

    return app
