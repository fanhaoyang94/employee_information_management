from flask_jwt_extended import JWTManager, get_jwt_identity, create_access_token
from flask import jsonify

jwt = JWTManager()


# 未登录响应
@jwt.unauthorized_loader
def unauthorized_callback(callback):
    return jsonify(message='Unauthorized, please log in'), 401


# 令牌过期响应
@jwt.expired_token_loader
def expired_token_callback(expired_token):
    return jsonify(message='Token has expired, please refresh or log in again'), 401


def create_token(username):
    access_token = create_access_token(identity=username)
    return access_token


def refresh_token():
    identity = get_jwt_identity()
    access_token = create_token(identity)
    return access_token
