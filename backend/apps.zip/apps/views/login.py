from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from apps.utils.auth import refresh_token, create_token

auth_view = Blueprint('auth_view', __name__)


@auth_view.route('/login', methods=['POST'])
def login():
    username = request.values.get('username')
    password = request.values.get('password')
    # TODO: 校验用户信息
    if username:
        access_token = create_token
        return jsonify(access_token=access_token)
    else:
        return jsonify({'msg': "用户名或密码错误"})


@auth_view.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    access_token = refresh_token()
    return jsonify(access_token=access_token)
